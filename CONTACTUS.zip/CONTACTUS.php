<style type="text/css">
<!--
.style1 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-weight: bold;
	font-style: italic;
	font-size: xx-large;
	color: #003399;
}
-->
</style>
<form action="" method="post">
<table width="1270" border="1" align="center">
  <tr bgcolor="#FFFFFF">
    <td colspan="2" align="center"><span class="style1">Contact Us...</span></td>
    </tr>
  <tr bgcolor="#FFFFFF">
    <td width="156">NAME:</td>
    <td width="1098">TMT Airlines..</td>
  </tr>
  <tr bgcolor="#FFFFFF">
    <td>ADDRESS:</td>
    <td>Athwalines, Athwa Gate, Surat, Gujarat 395001</td>
  </tr>
  <tr bgcolor="#FFFFFF">
    <td>CONTACT:</td>
    <td><a data-dtype="d3ifr" data-local-attribute="d3ph" jscontroller="LWZElb" href="https://www.google.com/search?gs_ssp=eJzj4tFP1zfMSDMuTrcwrDJgtFI1qDBOSjUwSTW3TE41TzMzME2xMqhINk01trBINUg2TbNMTUtN8xItyS1RSEpOVEjOz8lJTU9VKC4tSiwBAFmQF8I&q=tmt+bca+college+surat&rlz=1C1ONGR_enIN965IN965&oq=tmt+bca&aqs=chrome.2.69i57j0i512j46i175i199i512.6649j0j7&sourceid=chrome&ie=UTF-8#" jsdata="QKGTRc;_;AQ8xPc" jsaction="rcuQ6b:npT2md;F75qrd" data-ved="2ahUKEwi5vYbV8a3zAhWq4zgGHTyHCe0QkAgoAHoECDYQAw"><span aria-label="Call phone number 0261 246 0995">0261 246 0995</span></a></td>
  </tr>
  <tr bgcolor="#FFFFFF">
    <td>Email ID:</td>
    <td>TMTAirlines@yahoo.com</td>
  </tr>
  <tr bgcolor="#FFFFFF">
    <td height="32" colspan="2" align="center"><label>
      <input type="submit" name="back" id="button" value="BACK" >
    </label></td>
    </tr>
</table>

</form>

<?php
 if (isset($_REQUEST['back']))
{
	header('location:HOMEPAGE.php');
 }
 ?>