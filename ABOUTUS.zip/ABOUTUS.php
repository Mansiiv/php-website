<style type="text/css">
<!--
.style2 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-weight: bold;
	font-style: italic;
}
-->
</style>
<form name="form1" method="post" action="">
<table width="1143" border="1">
  <tr>
    <td width="822" rowspan="2"><img src="image/aboutus.jpg" alt="flight" width="822" height="493"></td>
    <td width="305" height="40"><div align="left"><span class="style2">All About TMT Airlines....</span></div></td>
  </tr>
  <tr>
    <td height="136"><p>
      <label></label>
      <br>
      Nurtured from the seed of a single great idea - to empower the traveller - TMT Airlines is a pioneer in India’s online travel industry. Founded in the year 2021 by Princy donda,Janvi donda and Khushi Beladiya, TMT Airlines came to life to empower the Indian traveller with instant bookings and comprehensive choices. The company initiated its journey serving the US-India travel market offering a range of best-value products and services powered by technology and round-the-clock customer support.</p>      
      <p>After consolidating its position in the market as a brand recognised for its reliability and transparency, TMT Airlines launched its India operations in 2021. With more and more Indians initiating to transact online with IRCTC and new opportunities with the advent of low cost carriers, TMT Airlines offered travellers the convenience of booking travel online with a few clicks.</p>
      <p>TMT Airline's rise has been led by the vision and the spirit of each one of its employees, for whom no idea was too big and no problem too difficult. With untiring determination, TMT Airlines has proactively diversified its product offering, adding a variety of online and offline products and services. TMT Airlines has stayed ahead of the curve by continually evolving its technology to meet the ever-changing demands of the rapidly developing global travel market, steadily establishing itself as India’s leading online travel company.<br>
      </p>
      <p></p></td>
  </tr>
  <tr>
    <td height="28" colspan="2" align="center"><label>
      <input type="submit" name="back" id="button" value="BACK">
    </label></td>
  </tr>
</table>

</form>

 <?php
 if (isset($_REQUEST['back']))
{
	header('location:HOMEPAGE.php');
 }
 ?>